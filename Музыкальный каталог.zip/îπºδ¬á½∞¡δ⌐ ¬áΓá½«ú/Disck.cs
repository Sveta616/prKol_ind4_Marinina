﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Музыкальный_каталог
{
    class Disck
    {
            private string num;
            private string ispol;
            private string name;


            public string Num
            {
                get { return num; }
                set { num = value; }
            }

            public string Ispol
            {
                get { return ispol; }
                set { ispol = value; }
            }

            public string Name
            {
                get { return name; }
                set { name= value; }
            }

        }
    }
