﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
namespace Музыкальный_каталог
{


    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Hashtable d = new Hashtable();
        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

           
            string num = Convert.ToString(numericUpDown1.Value);
            string ispol = textBox1.Text;
            string name = textBox2.Text;
            Disck d1 = new Disck();
            d1.Num = num;
            d1.Ispol = ispol;
            d1.Name = name;
            if(d.Contains(num))
            {
                MessageBox.Show("Этот номер уже существует");
            }
            else
            {
                if(d!=null)
                {
                    d.Add(d1.Num, d1);
                }
            }
            if (d.Contains(name))
            {
                MessageBox.Show("Эта песня уже добавлена");
            }
            else
            {
                if (d != null)
                {
                    d.Add(d1.Name, d1);
                }
            }
            if (num == "" || name == "" || ispol == "")
            {
                MessageBox.Show("Заполните поле");
            }
            else
                dataGridView1.Rows.Add(num, ispol, name);

        }
      

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.Columns.Add("Katalog", "Номер диска");
            dataGridView1.Columns.Add("Singer", "Исполнитель");
            dataGridView1.Columns.Add("Name", "Название песни");

        }

        private void button3_Click(object sender, EventArgs e)
        {

            if (textBox3.Text == "")
            {
                MessageBox.Show("Введите данные корректно");

            }
            else
            {
                string st = textBox3.Text;
                for (int i = 0; i < dataGridView1.RowCount; i++)
                {
                    dataGridView1.Rows[i].Selected = false;
                    for (int j = 0; j < dataGridView1.ColumnCount; j++)
                    {
                        if (dataGridView1.Rows[i].Cells[j].Value != null)
                        {
                            if (dataGridView1.Rows[i].Cells[j].Value.ToString().Contains(st))
                            {
                                dataGridView1.Rows[i].Selected = true;
                                break;
                            }
                        }
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int delete = dataGridView1.SelectedCells[0].RowIndex;
            d.Remove(dataGridView1.SelectedRows);
            dataGridView1.Rows.RemoveAt(delete);
        }
    }
}
